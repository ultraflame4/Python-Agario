# Python Agario
# Description:

  Basically Agario but in Python and singleplayer and offline
## Instruction:
Extract "Python Agario.zip"
### For Windows,
**Run "Start.bat"**
### For Everything Else:
**Run "main.pyc" directly or from terminal\console**
### For Source Code , "pygame" module needed


# Changelog:
## Update(rw0.6-pre): Small Changes
- Player now grows the more dots they eat.
- Player and dots size changed

## Update(rw 0.5): Release!
### First Rewrite Release
- removed lifes counter
- Score counter now works
- added dots
- dots functions correctly

## Update(rw 0.2): User Interface

- Main user interface is complete

## Update(rewrite 0.1): Complete Rewrite 0.1
- Changed name from 'Blocky Getty Dotty' to 'Python Agario'
- Finshed Player Movement , Controls



~~Instruction In The Game   (PAUSE IT)~~


~~Added More Dots~~
~~Lives System Implemented~~
~~(scores Resets Upon Death)~~

~~Modules needed:~~
~~Random,~~
~~pygame,~~
~~time.~~
