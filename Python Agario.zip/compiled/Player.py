import  pygame
class player:
    def __init__(self,surface,color,w=10,h=10,x=10,y=10):
        self.surface = surface
        self.color = color
        self.width = w
        self.height = h
        self.X = x
        self.Y = y
        self.rect = pygame.rect.Rect((self.X, self.Y, self.width, self.height))
        self.player = pygame.draw.rect(self.surface, self.color, self.rect)
        self.surfaceSize = pygame.display.get_surface()
    def movement(self):
        key = pygame.key.get_pressed()
        if key[pygame.K_a] and self.rect[0] > 0:
            self.rect.move_ip((-(self.width/2)), 0)

        if key[pygame.K_d] and (self.rect[0] + self.width) < 700:
            self.rect.move_ip((self.width/2), 0)

        if key[pygame.K_w] and self.rect[1] > 0:
            self.rect.move_ip(0, (-(self.height/2)))

        if key[pygame.K_s] and (self.rect[1] + self.height) < 700:
            self.rect.move_ip(0, (self.height/2))

    def draw(self):
        self.movement()
        pygame.draw.rect(self.surface, self.color, self.rect)
        player_pos_report = ('Player pos X: ' + str(self.rect[0]) + ' Y: ' + str(self.rect[1]))

        print('Player pos X: ' + str(self.rect[0]) + ' Y: ' + str(self.rect[1]))
